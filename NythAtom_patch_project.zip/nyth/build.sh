#!/usr/bin/env bash
# Nyth Atom - decode, patch, rebuild, align, sign, verify.
# Requires: JDK 17+, apktool >= 2.9 (with aapt2), Android build-tools 34+ (zipalign, apksigner,
# aapt2 optional), python3 + Pillow (only to regenerate icons), keytool.
set -euo pipefail
cd "$(dirname "$0")"

ORIG="${ORIG_APK:-backup/ZenoATom_7_0.apk}"
EXPECTED_SHA256="8f0ac2a0bf898216683c7c0727828e817679aeeca371ddbd9de8a80e0e4cc3e1"
KS="${NYTH_KEYSTORE:-nyth-release.jks}"
ALIAS="${NYTH_KEY_ALIAS:-nyth}"
OUT="build/NythAtom-7.0-nyth1-signed.apk"

for t in java keytool apktool zipalign apksigner python3 sha256sum; do
  command -v "$t" >/dev/null || { echo "Missing required tool: $t" >&2; exit 1; }
done

actual="$(sha256sum "$ORIG" | cut -d' ' -f1)"
[ "$actual" = "$EXPECTED_SHA256" ] || { echo "Input APK is not the ZenoATom 7.0 this patch was written for." >&2; exit 1; }

rm -rf work build; mkdir -p build

echo "== 1/6 decode";  apktool d -f "$ORIG" -o work
echo "== 2/6 patch";   python3 apply_patch.py work
if grep -qE "versionName: " work/apktool.yml; then
  sed -i -E "s/versionName: .*/versionName: '7.0-nyth1'/" work/apktool.yml
fi
echo "== 3/6 rebuild"; apktool b work -o build/unsigned.apk
echo "== 4/6 align";   zipalign -p -f 4 build/unsigned.apk build/aligned.apk

echo "== 5/6 sign"
if [ ! -f "$KS" ]; then
  echo "No keystore at $KS - generating a NEW one (this is NOT the original ZenoATom key)."
  : "${NYTH_KS_PASS:?Set NYTH_KS_PASS (keystore password, >= 6 chars) in your shell; it is never stored.}"
  keytool -genkeypair -v -keystore "$KS" -alias "$ALIAS" -keyalg RSA -keysize 2048 \
          -validity 10000 -storepass "$NYTH_KS_PASS" -keypass "$NYTH_KS_PASS" \
          -dname "CN=Nyth Atom, C=MM"
fi
: "${NYTH_KS_PASS:?Set NYTH_KS_PASS}"
apksigner sign --ks "$KS" --ks-key-alias "$ALIAS" --ks-pass env:NYTH_KS_PASS \
          --out "$OUT" build/aligned.apk

echo "== 6/6 verify"
apksigner verify --verbose --print-certs "$OUT"
if command -v aapt2 >/dev/null; then
  aapt2 dump badging "$OUT" | grep -E "^package:|application-label:|launchable-activity" || true
fi
echo
echo "Built: $OUT"
echo "Install (original must be uninstalled first: different signing key):"
echo "  adb uninstall com.zenoatom.app ; adb install $OUT"
echo "Keep $KS private and out of version control."
