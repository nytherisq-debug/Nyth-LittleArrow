# Analysis of ZenoATom 7.0 (from the supplied decompiled sources)

Evidence level: **R** = read in the decompiled Java/smali; **I** = inferred; **U** = not determined.

## App facts
- R: package `com.zenoatom.app`, versionName 7.0 / code 8, minSdk 21, target 34, Java, no native libs.
- R: launcher `SplashActivity` → `d.w(ctx)` (stored session?) → `DashboardActivity` else `LoginActivity`.
- R: signed with a self-made key (`CN=Felix Zeno`), not a debug key. No in-app signature/tamper check found
  (only Firebase's `getPackageInfo(…, 0)` version lookup).

## Login (kept unchanged)
- R: `send-otp` POST `https://store.atom.com.mm/mytmapi/v1/my/local-auth/send-otp?msisdn=&userid=-1&v=4.14.1`,
  body `{"msisdn":"<digits, leading 0 and 95 stripped>"}`; reads `data.attribute.code`.
- R: `verify-otp` (`E0.x.ah`) on the matching URL; reads `data.attribute.{token,user_id,msisdn,refresh_token,
  access_token_expire_at}`, then `d.ae()` stores the account. Refresh via `/v3/my/oauth/refresh-token`.
- R: storage is plain `SharedPreferences("zenoatom_prefs")` (`accounts_json`, `active_msisdn`, legacy `token`…).
  Hardening to encrypted storage was **not** done: it changes the session layer you asked me to preserve.
- R: the app identifies itself to Atom as client versions 4.14.1 / 4.16.2 and signs `packs/buy` requests with a
  constant embedded in the code. This is original behavior and was not touched. Make sure you are permitted to
  use Atom's private API this way.

## City Run (kept unchanged) — differs from the assumed "OTP login authenticates the game"
- R: `CityRunActivity` is **not** a bare game WebView. It builds its own account list (coins, runs, milestones,
  coin→run redemption via `/processCoinsRedemption`, plan purchase) and opens the game in an overlay WebView.
- R: on open it loads `http://blatom.cityrun.pro/home/GetGWMDN?source=https%3a%2f%2fcityrun.pro%2f%3fpop2home%3dfalse`
  (cleartext). `C0110q`/`CityRunActivity.r()` watch redirected URLs: `/playgame` or `status=0` closes the loader;
  a `msisdn=` query parameter is captured and handed to a background task (`RunnableC0106m`).
- R: that task's decompilation **failed** (jadx "Method dump skipped"), as did `RunnableC0105l.run` (plan
  loading) and `CityRunActivity.s` (account card). I did not read their smali, so how the msisdn becomes the
  account record, and the game API base URL used by `d.a(…, "/getUserData")`, are **U**.
- R: `user_id` for the game comes from the server's `getUserData` response (`d.v`) or an existing record; the
  game URL is `https://cityrun.pro/final_games/toh-toh-v78/?user_id=<id>&user_type=sub`.
- R: if no msisdn arrives (18 s timer) the screen tells the user to use Atom mobile data with VPN off.
  I: the carrier gateway therefore identifies the SIM by network; the OTP login is **not** what authenticates
  City Run. The OTP session is used for Atom pack purchase and other Atom API calls.
- Consequence: on Wi-Fi, VPN, another carrier, or if the gateway/host is down, the msisdn never arrives and
  City Run will not authenticate, regardless of a successful OTP login.

## Transport / WebView audit
- R: manifest `usesCleartextTraffic="true"`; the gateway is HTTP and is probably reached through carrier
  redirects over HTTP. HTTPS support and redirect hosts could not be tested offline, so nothing was migrated
  or restricted. Risk: the msisdn travels in cleartext URLs on that hop.
- R: WebView enables JavaScript and DOM storage and sets a custom desktop-Chrome-on-Redmi user agent; no
  explicit file-access flags and no domain allowlist. Left as is.

## Why the old screens are not deleted
Dashboard/Accounts/etc. share helpers (`d`, `E0.x`, `l0.*`) with login and CityRun. They are unreachable now;
physical removal needs a dependency trace plus a device regression run.
