# Test status (honest)

| Item | Status | Evidence |
|---|---|---|
| Patch applies to the decompiled dump (all assertions) | **Passed** | `apply_patch.py` run on a copy of the dump |
| Patched XML is well-formed | **Passed** | parsed every res xml + manifest |
| Nav sites now target HomeActivity | **Passed (static)** | grep of patched smali |
| Icon/logo render | **Passed** | previewed PNG |
| `apktool d` / `apktool b` rebuild | **Blocked** | apktool, SDK, network not available |
| HomeActivity.smali assembles | **Untested** | hand-written, never assembled |
| zipalign / apksigner verify | **Blocked** | tools not available |
| Install, launch, crash log | **Untested** | no device/emulator |
| Phone validation, OTP send/verify, errors | **Untested** | needs device + authorized account |
| Session restore, sign-out | **Untested** | |
| Home shows only City Run | **Untested** | |
| Gateway redirect + msisdn capture | **Untested** | needs Atom mobile data, VPN off |
| Game loads / is playable | **Untested** | page load ≠ playable; must be played |
| Network loss, Back, rotation, process death | **Untested** | |
| Contrast of recolored City Run screen | **Untested** | white text on gold likely |

## Device script (after building)
1. `adb install` the APK; `adb logcat -c`. Launch: splash → login (gold/charcoal, "Nyth Atom").
2. Enter your own Atom number, request OTP once, verify. Expect Home (City Run, Play Now, Sign out).
3. Kill and reopen: expect splash → Home directly. Tap Play Now twice quickly: one City Run screen only.
4. On Atom mobile data, VPN off: expect auto-login overlay, then the City Run accounts screen; open the game
   and actually play a round. Repeat on Wi-Fi to confirm the documented "use mobile data" message.
5. Back from City Run → Home. Sign out → Login; reopen app → Login (no session).
6. Airplane mode during step 4; then restore and retry. `adb logcat` for crashes.
