#!/usr/bin/env python3
"""
Nyth Atom patcher.  Operates on an `apktool d` output directory of ZenoATom 7.0
(package com.zenoatom.app, versionCode 8).  Every edit asserts that the expected
original pattern exists, so a wrong/different APK fails loudly instead of being
silently half-patched.

Usage: python3 apply_patch.py <apktool_dir>
"""
import colorsys, glob, os, re, shutil, sys

HERE = os.path.dirname(os.path.abspath(__file__))
OVERLAY = os.path.join(HERE, "overlay")

def die(msg):
    sys.exit("PATCH FAILED: " + msg)

def read(p):
    with open(p, encoding="utf-8") as f:
        return f.read()

def write(p, s):
    with open(p, "w", encoding="utf-8", newline="\n") as f:
        f.write(s)

def find_smali(root, rel):
    hits = [os.path.join(d, rel) for d in sorted(glob.glob(os.path.join(root, "smali*")))
            if os.path.isfile(os.path.join(d, rel))]
    if len(hits) != 1:
        die(f"expected exactly one smali file for {rel}, found {len(hits)}")
    return hits[0]

# ---------------------------------------------------------------- 1. manifest
def patch_manifest(root):
    p = os.path.join(root, "AndroidManifest.xml")
    s = read(p)
    if 'package="com.zenoatom.app"' not in s:
        die("manifest package is not com.zenoatom.app (wrong APK?)")
    s, n = re.subn(r'(<application\b[^>]*?android:label=")[^"]*(")', r'\1Nyth Atom\2', s, count=1)
    if n != 1: die("application android:label not found")
    # Session tokens live in plain SharedPreferences: do not let them into adb/cloud backups.
    s, n = re.subn(r'android:allowBackup="true"', 'android:allowBackup="false"', s, count=1)
    if n != 1: die("android:allowBackup=true not found")
    if "com.zenoatom.app.HomeActivity" in s:
        die("manifest already patched")
    decl = ('        <activity android:theme="@style/Theme.ZenoATom.DarkBar" '
            'android:name="com.zenoatom.app.HomeActivity" android:exported="false"/>\n')
    if "</application>" not in s: die("</application> not found")
    s = s.replace("</application>", decl + "    </application>", 1)
    # NOTE: usesCleartextTraffic intentionally kept: the City Run gateway
    # (http://blatom.cityrun.pro/...) is plain HTTP and was not verified over HTTPS.
    write(p, s)

# ---------------------------------------------------------------- 2. navigation (smali)
NAV_SITES = [  # (file, expected number of Dashboard const-class sites)
    ("com/zenoatom/app/SplashActivity.smali", 1),   # splash -> (session ? Dashboard : Login)
    ("com/zenoatom/app/LoginActivity.smali", 1),    # onCreate: already logged in
    ("com/bumptech/glide/q.smali", 1),              # l0.X verify-OTP success (non add-account mode)
]
def patch_navigation(root):
    for rel, expect in NAV_SITES:
        p = find_smali(root, rel)
        s = read(p)
        pat = re.compile(r"(const-class v\d+, )Lcom/zenoatom/app/DashboardActivity;")
        n = len(pat.findall(s))
        if n != expect:
            die(f"{rel}: expected {expect} DashboardActivity const-class, found {n}")
        write(p, pat.sub(r"\1Lcom/zenoatom/app/HomeActivity;", s))
    dst_dir = os.path.join(root, "smali", "com", "zenoatom", "app")
    os.makedirs(dst_dir, exist_ok=True)
    shutil.copy(os.path.join(OVERLAY, "smali", "com", "zenoatom", "app", "HomeActivity.smali"), dst_dir)

# ---------------------------------------------------------------- 3. resources
def copy_overlay_res(root):
    src = os.path.join(OVERLAY, "res")
    for dp, _, files in os.walk(src):
        for f in files:
            s = os.path.join(dp, f)
            d = os.path.join(root, "res", os.path.relpath(s, src))
            os.makedirs(os.path.dirname(d), exist_ok=True)
            shutil.copy(s, d)

HEX = re.compile(r"#([0-9a-fA-F]{8}|[0-9a-fA-F]{6})\b")
GOLD = (0xC9, 0xA2, 0x4B)

def remap_hex(m):
    """Hue-based remap: navy/dark blues -> warm charcoal, saturated non-red -> gold.
    Greys/whites/blacks and reds (error states) are left alone."""
    h = m.group(1)
    a, rgb = (h[:2], h[2:]) if len(h) == 8 else ("", h)
    r, g, b = (int(rgb[i:i + 2], 16) for i in (0, 2, 4))
    hh, ss, vv = colorsys.rgb_to_hsv(r / 255, g / 255, b / 255)
    if ss < 0.18:
        return m.group(0)
    deg = hh * 360
    if deg < 22 or deg > 335:      # red family: keep for error states
        return m.group(0)
    if vv < 0.42:                  # dark navy/indigo -> warm charcoal
        k = vv * 0.45 * 255
        nr, ng, nb = int(k), int(k * 0.985), int(k * 0.95)
    else:                          # bright accent -> champagne gold (lighter ones lighter)
        t = 0.0 if vv < 0.8 else 0.35
        nr, ng, nb = (int(c + (255 - c) * t * 0.5) for c in GOLD)
    return f"#{a}{nr:02x}{ng:02x}{nb:02x}"

RECOLOR = [
    "layout/activity_login.xml", "layout/activity_splash.xml", "layout/activity_cityrun.xml",
    "layout/item_cityrun_account.xml", "layout/dialog_buy.xml", "layout/dialog_success.xml",
    "layout/dialog_error.xml", "layout/dialog_closed.xml", "layout/dialog_notification.xml",
    "drawable/bg_app_gradient.xml", "drawable/bg_splash_progress.xml",
    "drawable/bg_splash_progress_fill.xml", "drawable/bg_splash_progress_track.xml",
    "drawable/bg_btn_buy_pill.xml", "drawable/bg_btn_success_pill.xml",
    "drawable/bg_btn_redeem_pill.xml", "drawable/bg_btn_update_pill.xml",
    "drawable/bg_btn_outline_pill.xml", "drawable/bg_dialog_cancel.xml",
    "drawable/bg_buy_icon.xml", "drawable/bg_pack_row.xml",
] + [os.path.relpath(p, "") for p in []]

def recolor(root):
    resdir = os.path.join(root, "res")
    files = list(RECOLOR) + [os.path.relpath(p, resdir).replace(os.sep, "/")
                             for p in glob.glob(os.path.join(resdir, "drawable", "bg_cr_*.xml"))]
    seen = set()
    for rel in files:
        if rel in seen: continue
        seen.add(rel)
        p = os.path.join(resdir, rel)
        if not os.path.isfile(p):
            print(f"  (skip, not present: {rel})"); continue
        s = read(p)
        write(p, HEX.sub(remap_hex, s))

def patch_login_and_splash(root):
    res = os.path.join(root, "res")
    p = os.path.join(res, "layout", "activity_login.xml")
    s = read(p)
    for old, new in (('android:text="ZenoATom"', 'android:text="Nyth Atom"'),
                     ('android:text="Login Your ATom Phone number"',
                      'android:text="Sign in with your Atom phone number"')):
        if old not in s: die(f"activity_login.xml: missing {old}")
        s = s.replace(old, new)
    # dark label on the gold buttons for contrast (only <Button> blocks using bg_btn_pill*)
    def fix_button(m):
        b = m.group(0)
        return b.replace('android:textColor="#ffffff"', 'android:textColor="#0b0b0d"') \
            if "bg_btn_pill" in b else b
    s = re.sub(r"<Button\b.*?/>", fix_button, s, flags=re.S)
    write(p, s)
    # the title colour (#22c55e) was already remapped to gold by recolor()
    p = os.path.join(res, "layout", "activity_splash.xml")
    s = read(p)
    if 'android:text="ZenoATom"' not in s: die("activity_splash.xml: brand text not found")
    write(p, s.replace('android:text="ZenoATom"', 'android:text="Nyth Atom"'))

def patch_values(root):
    res = os.path.join(root, "res")
    p = os.path.join(res, "values", "strings.xml")
    s = read(p)
    s, n = re.subn(r'(<string name="app_name">)[^<]*(</string>)', r'\1Nyth Atom\2', s)
    if n != 1: die("app_name string not found")
    write(p, s)
    p = os.path.join(res, "values", "colors.xml")
    s = read(p)
    wanted = {"bg_dark": "#0b0b0d", "primary": "#c9a24b", "primary_end": "#e6d3a3",
              "toolbar_gold": "#0b0b0d", "fcm_notification_color": "#c9a24b"}
    for name, val in wanted.items():
        s, n = re.subn(r'(<color name="%s">)[^<]*(</color>)' % re.escape(name), r"\g<1>%s\2" % val, s)
        if n != 1: die(f"color {name} not found exactly once (found {n})")
    write(p, s)

def main():
    if len(sys.argv) != 2: sys.exit(__doc__)
    root = os.path.abspath(sys.argv[1])
    if not os.path.isfile(os.path.join(root, "AndroidManifest.xml")):
        die("not an apktool output directory (no AndroidManifest.xml)")
    steps = [("manifest", patch_manifest), ("navigation + HomeActivity", patch_navigation),
             ("resource overlay (icons, home, drawables)", copy_overlay_res),
             ("palette remap", recolor), ("login/splash text", patch_login_and_splash),
             ("app_name + colors", patch_values)]
    for name, fn in steps:
        print(f"[patch] {name}")
        fn(root)
    print("[patch] done")

if __name__ == "__main__":
    main()
