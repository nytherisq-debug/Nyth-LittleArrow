# Nyth Atom — City Run Only Edition (patch project for ZenoATom 7.0)

Rebrands the working ZenoATom 7.0 APK (`com.zenoatom.app`, versionCode 8) as **Nyth Atom**, keeps the
original Atom OTP login and the original City Run gateway flow, and routes the app to a single
City Run home screen. It is an **apktool patch project**, not a Gradle project: the supplied ZIP is a
jadx/smali dump (no `build.gradle`, obfuscated names), so rebuilding from the original APK is the
safest route.

> **Status: patch written and dry-run against the decompiled dump only. Not built, not signed,
> not installed, not run.** The authoring environment had no apktool, Android SDK, device or network.
> See `docs/TEST_STATUS.md` for exactly what was and was not verified.

## Layout
| Path | Purpose |
|---|---|
| `backup/ZenoATom_7_0.apk` | untouched original (+ `SHA256SUMS.txt`) |
| `apply_patch.py` | edits an `apktool d` directory; asserts every expected pattern, fails loudly |
| `overlay/smali/.../HomeActivity.smali` | new City Run home screen (hand-written smali) |
| `overlay/res/` | new icons, logo, home layout, gold/charcoal drawables, colors, strings |
| `tools/make_assets.py` | regenerates the original Nyth Atom icon/logo (Pillow) |
| `build.sh` | decode → patch → rebuild → zipalign → sign → verify |
| `docs/ANALYSIS.md` | what the original code does (traced), risks, limits |
| `docs/TEST_STATUS.md` | pass / blocked / untested table and a device test script |

## Build (on a machine with the tools)
Requirements: JDK 17+, apktool ≥ 2.9 (bundles aapt2), Android build-tools 34+ (`zipalign`, `apksigner`),
python3 (+ Pillow only to regenerate icons), `keytool`.
```bash
export NYTH_KS_PASS='choose-a-password'   # never written to disk by the scripts
./build.sh                                # output: build/NythAtom-7.0-nyth1-signed.apk
adb uninstall com.zenoatom.app            # required, see "Signing" below
adb install build/NythAtom-7.0-nyth1-signed.apk
```
If `apktool b` or smali assembly reports an error in `HomeActivity.smali`, send me the message; that file
was written by hand and has never been assembled.

## What changes
1. **Package ID unchanged** (`com.zenoatom.app`). Login, API, session and gateway code is not edited.
2. **Manifest:** label → `Nyth Atom`; `allowBackup` → `false` (the Atom token and refresh token are stored in
   plain SharedPreferences `zenoatom_prefs`); `HomeActivity` declared. `usesCleartextTraffic` is **kept**
   (see ANALYSIS: the gateway is HTTP and HTTPS was not verified).
3. **Navigation (3 smali sites):** `SplashActivity`, `LoginActivity.onCreate`, and the verify-OTP success
   handler (`glide/q`) now start `HomeActivity` instead of `DashboardActivity`.
4. **HomeActivity:** session guard (same `d.w()` check the original uses), account line, **Play Now**
   (disabled while launching, re-enabled on resume) → original `CityRunActivity`; **Sign out** clears
   `zenoatom_prefs` (what the original does when the last account is removed) and WebView cookies.
5. **Branding:** icon (legacy PNG + adaptive), in-app logo, splash/login text, dark charcoal + champagne-gold
   palette (`colors.xml`, login/splash layouts, City Run drawables via a hue remap that leaves reds alone).
6. **Not deleted:** Dashboard, Accounts, History, Points, Claim, Redeem and LittleArrow activities remain
   in the APK but have no entry point. They are left in place because their dependency graph with the
   login/session code was not fully traced.

## Signing and upgrade compatibility
The original is signed by `CN=Felix Zeno` (RSA-2048, SHA-256
`80:67:F8:1F:…:0A:03`). That key was not supplied, so the rebuilt APK **cannot** be signed with it. Android
will refuse to install it over the original (`INSTALL_FAILED_UPDATE_INCOMPATIBLE`); uninstall first, which
also removes the stored session, so you log in again. Any server-side or Google/Firebase setting tied to the
original certificate fingerprint was not examined and may not accept the new one (push notifications are the
likeliest). `build.sh` generates a new keystore for you; keep it private.

## Known gaps (details in docs/ANALYSIS.md)
- The City Run screen is the original programmatic UI (accounts, coin redeem, plan purchase). Only its
  colors/drawables were remapped; some text may have poor contrast until checked on a device.
- No WebView domain allowlist was added; the original does not have one and adding it blind could break
  gateway redirects.
- Gameplay and the carrier gateway require Atom mobile data with VPN off; none of it has been exercised.
