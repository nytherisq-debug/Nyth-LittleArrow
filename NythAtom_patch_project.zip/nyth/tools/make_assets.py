#!/usr/bin/env python3
"""Generates the original Nyth Atom brand assets (logo + launcher icons).
Requires Pillow. Output is written into ../overlay/res."""
import math, os
from PIL import Image, ImageDraw, ImageFilter

BG = (11, 11, 13, 255)
GOLD = (201, 162, 75, 255)
CHAMP = (230, 211, 163, 255)
SS = 4  # supersampling

def mark(size, pad=0.12):
    """Atom mark: three rotated gold orbits + nucleus + electrons."""
    S = size * SS
    im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    cx = cy = S / 2
    r = S * (0.5 - pad)
    for ang in (0, 60, 120):
        layer = Image.new("RGBA", (S, S), (0, 0, 0, 0))
        d = ImageDraw.Draw(layer)
        w, h = r * 2, r * 0.62
        d.ellipse([cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2],
                  outline=GOLD, width=max(2, int(S * 0.028)))
        layer = layer.rotate(ang, resample=Image.BICUBIC, center=(cx, cy))
        im = Image.alpha_composite(im, layer)
    d = ImageDraw.Draw(im)
    n = S * 0.085
    d.ellipse([cx - n, cy - n, cx + n, cy + n], fill=CHAMP)
    for ang in (20, 140, 260):
        a = math.radians(ang)
        ex, ey = cx + r * 0.9 * math.cos(a), cy + r * 0.28 * math.sin(a)
        e = S * 0.026
        d.ellipse([ex - e, ey - e, ex + e, ey + e], fill=CHAMP)
    return im.resize((size, size), Image.LANCZOS)

def rounded_icon(size):
    S = size * SS
    mask = Image.new("L", (S, S), 0)
    ImageDraw.Draw(mask).rounded_rectangle([0, 0, S - 1, S - 1], radius=int(S * 0.22), fill=255)
    base = Image.new("RGBA", (S, S), BG)
    glow = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    ImageDraw.Draw(glow).ellipse([-S * 0.2, -S * 0.3, S * 0.8, S * 0.6], fill=(201, 162, 75, 40))
    glow = glow.filter(ImageFilter.GaussianBlur(S * 0.08))
    base = Image.alpha_composite(base, glow)
    base.putalpha(mask)
    base = base.resize((size, size), Image.LANCZOS)
    return Image.alpha_composite(base, mark(size, pad=0.17))

root = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "overlay", "res")
def out(rel, im):
    p = os.path.join(root, rel)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    im.save(p)

for dens, px in (("mdpi", 48), ("hdpi", 72), ("xhdpi", 96), ("xxhdpi", 144), ("xxxhdpi", 192)):
    out(f"mipmap-{dens}/ic_launcher.png", rounded_icon(px))
fg = Image.new("RGBA", (432, 432), (0, 0, 0, 0))   # 108dp @ xxxhdpi, mark inside safe zone
fg.alpha_composite(mark(300, pad=0.04), (66, 66))
out("drawable-nodpi/nyth_launcher_fg.png", fg)
out("drawable/ic_app_logo.png", mark(256, pad=0.06))  # same 256x256 RGBA contract as original
print("assets written")
